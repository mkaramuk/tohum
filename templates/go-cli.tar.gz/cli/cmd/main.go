package main

func main() {
	println("Hello from ${projectName}")
}
