console.log("Hello from {{ project_name }}");
