package main

func main() {
	println("Hello from {{ project_name }}")
}
